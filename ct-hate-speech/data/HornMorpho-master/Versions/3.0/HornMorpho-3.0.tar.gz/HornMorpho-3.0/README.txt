This is version 3.0 of HornMorpho, a Python program that performs morphological
analysis and generation of Amharic, Oromo, and Tigrinya words.
HornMorpho is part of the Processing Languages of the Global South
project (http://homes.soic.indiana.edu/gasser/plogs.html).

To install HornMorpho, extract the files from the archive. Then go to
the directory HornMorpho-3.0 and do 

  python setup.py install

making sure that you are using Python 3.

For information about using the program, see the manuals that came with
the distribution: horn3.0.pdf and horn3.0_quick.pdf.
